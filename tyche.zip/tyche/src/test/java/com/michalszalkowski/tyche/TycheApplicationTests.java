package com.michalszalkowski.tyche;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TycheApplicationTests {

	@Test
	void contextLoads() {
	}

}
