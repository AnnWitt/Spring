# JAVAgda49 - Day 3

## Annotation
- @Entity
- @Table
- @RestController
- @Autowired
- @GetMapping
- @PostMapping
- @PutMapping
- @DeleteMapping