INSERT INTO book (id, title, author)
VALUES (1, 'The Lord Of The Rings', 'J.R.R. Tolkien'),
       (2, '1984', 'George Orwell'),
       (3, 'The Hitchhikers Guide To The Galaxy', 'Douglas Adams')
;
