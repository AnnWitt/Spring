package com.michalszalkowski.module.home;

public class GreetingDto {

	private String text;

	public GreetingDto(String text) {
		this.text = text;
	}

	public String getText() {
		return text;
	}
}
