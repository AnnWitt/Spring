package com.michalszalkowski;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AresApplication {

	public static void main(String[] args) {
		SpringApplication.run(AresApplication.class, args);
	}

}
